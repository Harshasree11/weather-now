import { useState } from "react";

/**
 * 🌤️ Weather Now App
 * Built using React + Open-Meteo API
 * - Shows current weather, "feels like" temperature, 3-day forecast, and hourly forecast.
 */

function App() {
    //State variables
  const [city, setCity] = useState(""); // User input city
  const [weather, setWeather] = useState(null); // Current weather data
  const [forecast, setForecast] = useState(null); // 3-day forecast
  const [error, setError] = useState(null); // Error messages
  const [hourly, setHourly] = useState(null); // Hourly forecast
  const [feelsLike, setFeelsLike] = useState(null); // "Feels like" temperature

/**
   * Weather code to emoji + description map
   */
 const weatherIcons = {
    0: { icon: "☀️", label: "Clear sky" },
    1: { icon: "🌤️", label: "Mainly clear" },
    2: { icon: "⛅", label: "Partly cloudy" },
    3: { icon: "☁️", label: "Overcast" },
    45: { icon: "🌫️", label: "Fog" },
    48: { icon: "🌫️", label: "Rime fog" },
    51: { icon: "🌦️", label: "Light drizzle" },
    53: { icon: "🌦️", label: "Moderate drizzle" },
    55: { icon: "🌧️", label: "Dense drizzle" },
    56: { icon: "🌦️", label: "Light freezing drizzle" },
    57: { icon: "🌧️", label: "Dense freezing drizzle" },
    61: { icon: "🌧️", label: "Slight rain" },
    63: { icon: "🌧️", label: "Moderate rain" },
    65: { icon: "🌧️", label: "Heavy rain" },
    66: { icon: "🌧️", label: "Light freezing rain" },
    67: { icon: "🌧️", label: "Heavy freezing rain" },
    71: { icon: "🌨️", label: "Slight snow fall" },
    73: { icon: "🌨️", label: "Moderate snow fall" },
    75: { icon: "❄️", label: "Heavy snow fall" },
    77: { icon: "❄️", label: "Snow grains" },
    80: { icon: "🌦️", label: "Slight rain showers" },
    81: { icon: "🌧️", label: "Moderate rain showers" },
    82: { icon: "🌧️", label: "Violent rain showers" },
    85: { icon: "🌨️", label: "Slight snow showers" },
    86: { icon: "❄️", label: "Heavy snow showers" },
    95: { icon: "⛈️", label: "Thunderstorm" },
    96: { icon: "⛈️", label: "Thunderstorm with slight hail" },
    99: { icon: "🌩️", label: "Thunderstorm with heavy hail" },
  };

   /**
   *  Fetch geographic coordinates for the given city name
   */
  async function getCoordinates(cityName) {
    const geoResponse = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${cityName}`
    );
    const geoData = await geoResponse.json();

    if (geoData.results && geoData.results.length > 0) {
      const result = geoData.results[0];
      return {
        latitude: result.latitude,
        longitude: result.longitude,
        name: result.name,
        country: result.country,
      };
    } else {
      throw new Error("City not found");
    }
  }

   /**
   *  Fetch weather, forecast, and hourly data for a given city
   */
  async function getWeather(cityName) {
    try {
      setError(null);
      setWeather(null);
      setForecast(null);

      const { latitude, longitude, name, country } = await getCoordinates(cityName);

      const response = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true&hourly=temperature_2m,apparent_temperature,windspeed_10m,weathercode&daily=temperature_2m_max,temperature_2m_min,weathercode&timezone=auto`
      );
      
      const data = await response.json();

      if (data.current_weather && data.daily) {
        setWeather({
          ...data.current_weather,
          name,
          country,
        });

        const forecastData = data.daily.time.slice(0, 3).map((date, index) => ({
          date,
          max: data.daily.temperature_2m_max[index],
          min: data.daily.temperature_2m_min[index],
          code: data.daily.weathercode[index],
        }));
        setForecast(forecastData);
        setHourly(data.hourly); 

         // "Feels like" = apparent temperature at current time index
        setFeelsLike(data.hourly.apparent_temperature[0]);
      } else {
        throw new Error("Weather data not available");
      }
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div
      style={{
        fontFamily: "Poppins, sans-serif",
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        background: "linear-gradient(to bottom right, #dbeafe, #ffffff)",
        paddingTop: "50px",
        paddingBottom: "40px", 
      }}
    >
      <div
        style={{
          backgroundColor: "white",
          padding: "40px 60px",
          borderRadius: "20px",
          boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
          textAlign: "center",
          width: "360px",
        }}
      >
        <h1 style={{ fontSize: "2rem", marginBottom: "20px", color: "#1e3a8a" }}>
          🌤️ Weather Now
        </h1>

        <div style={{ marginBottom: "20px" }}>
          <input
            type="text"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            placeholder="Enter city name"
            style={{
              padding: "10px",
              fontSize: "16px",
              borderRadius: "8px",
              border: "1px solid #ccc",
              width: "70%",
              marginRight: "8px",
            }}
          />
          <button
            onClick={() => getWeather(city)}
            style={{
              padding: "10px 15px",
              fontSize: "16px",
              borderRadius: "8px",
              backgroundColor: "#3b82f6",
              color: "white",
              border: "none",
              cursor: "pointer",
            }}
          >
            Get Weather
          </button>
        </div>

        {error && <p style={{ color: "red" }}>❌ {error}</p>}

        {weather && (
          <>
          <button
  onClick={() => {
    setWeather(null);
    setForecast(null);
    setCity("");
  }}
  style={{
    backgroundColor: "#e5e7eb",
    color: "#1e3a8a",
    border: "none",
    borderRadius: "8px",
    padding: "8px 12px",
    cursor: "pointer",
    fontSize: "14px",
    marginBottom: "10px",
  }}
>
  🔄 Search Another City
</button>

            <div style={{ marginTop: "20px", fontSize: "18px" }}>
              <div style={{ fontSize: "3rem" }}>
                {weatherIcons[weather.weathercode]?.icon || "❔"}
              </div>
              <h2 style={{ fontSize: "1.4rem", color: "#1e3a8a" }}>
                Weather in {weather.name}, {weather.country}
              </h2>
              <p>{weatherIcons[weather.weathercode]?.label || "Unknown weather"}</p>
              <p>🌡️ Temperature: {weather.temperature}°C</p>
              <p>🥵 Feels Like: {feelsLike?.toFixed(1)}°C</p>
              <p>💨 Wind Speed: {weather.windspeed} km/h</p>
            </div>

            {/* 🌦️ 3-Day Forecast Section */}
            {forecast && (
              <div
                style={{
                  marginTop: "25px",
                  borderTop: "1px solid #ddd",
                  paddingTop: "15px",
                }}
              >
                <h3 style={{ fontSize: "1.2rem", marginBottom: "10px" }}>
                  3-Day Forecast
                </h3>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  {forecast.map((day, index) => (
                    <div
                      key={index}
                      style={{
                        backgroundColor: "#eff6ff",
                        borderRadius: "10px",
                        padding: "10px",
                        width: "30%",
                      }}
                    >
                      <p style={{ fontWeight: "500" }}>
                        {new Date(day.date).toLocaleDateString("en-US", {
                          weekday: "short",
                        })}
                      </p>
                      <div style={{ fontSize: "1.5rem" }}>
                        {weatherIcons[day.code]?.icon || "❔"}
                      </div>
                      <p style={{ fontSize: "0.9rem" }}>
                        {day.min}° / {day.max}°C
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

          {/* ⏰ Hourly Forecast Section */}
{hourly && (
  <div
    style={{
      marginTop: "25px",
      borderTop: "1px solid #ddd",
      paddingTop: "15px",
    }}
  >
    <h3 style={{ fontSize: "1.2rem", marginBottom: "10px" }}>
      Next 12 Hours
    </h3>
    <div
      style={{
        display: "flex",
        overflowX: "auto",
        gap: "10px",
        paddingBottom: "10px",
      }}
    >
      {hourly.time.slice(0, 12).map((time, index) => {
        const temp = hourly.temperature_2m[index];
        const code = hourly.weathercode[index];
        const wind = hourly.windspeed_10m[index];
        const { icon, label } = weatherIcons[code] || { icon: "❔", label: "Unknown" };

        return (
          <div
            key={index}
            style={{
              backgroundColor: "#eff6ff",
              borderRadius: "10px",
              padding: "10px",
              minWidth: "90px",
              textAlign: "center",
            }}
          >
            <p style={{ fontSize: "0.8rem", fontWeight: "500" }}>
              {new Date(time).toLocaleTimeString("en-US", {
                hour: "numeric",
                hour12: true,
              })}
            </p>
            <div style={{ fontSize: "1.5rem" }}>{icon}</div>
            <p style={{ fontSize: "0.8rem" }}>{label}</p>
            <p style={{ fontSize: "0.9rem" }}>{temp}°C</p>
            <p style={{ fontSize: "0.7rem", color: "#555" }}>{wind} km/h</p>
          </div>
        );
      })}
    </div>
  </div>
)}
  
          </>
        )}
      </div>
    </div>
  );
}


export default App;