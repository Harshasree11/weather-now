import React from 'react'

export default function WeatherCard({ data }) {
  return (
    <div className='bg-white p-6 rounded-2xl shadow-md text-center w-80'>
      <h2 className='text-xl font-semibold mb-2'>
        {data.city}, {data.country}
      </h2>
      <p className='text-3xl mb-2'>{data.temp}°C</p>
      <p className='text-gray-600 mb-4'>Humidity: {data.humidity}%</p>

      <h3 className='font-medium text-gray-700 mb-2'>Next Days</h3>
      <div className='flex justify-center gap-2'>
        {data.forecast.slice(0, 3).map((temp, i) => (
          <div key={i} className='bg-blue-100 rounded-lg px-3 py-1'>
            {temp}°C
          </div>
        ))}
      </div>
    </div>
  )
}