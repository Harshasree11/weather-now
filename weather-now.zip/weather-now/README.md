# 🌤 Weather Now (React + Open-Meteo)
A simple weather app built with React, Tailwind CSS, and Open-Meteo API.


## ⚙️ Setup
```bash
npm install
npm run dev
```
